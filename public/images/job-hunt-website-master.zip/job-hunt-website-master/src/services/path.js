export const getCategoryPath = "/category/getallcategory";
export const getFeaturedJobPath = "/job/featuredjobs";
export const getLatestJobsPath = "/job/latestjobs"