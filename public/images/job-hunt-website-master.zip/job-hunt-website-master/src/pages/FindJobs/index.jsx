import React from "react";

import LandingPageTemplate from "../../components/templates/LandingPageTemplate";

export default function FindJobs() {
	return <LandingPageTemplate>Halaman Find Jobs</LandingPageTemplate>;
}
