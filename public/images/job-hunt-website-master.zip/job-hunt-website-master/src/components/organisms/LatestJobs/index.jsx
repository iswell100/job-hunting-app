import React, { useEffect } from 'react'

import ContentHeader from '../../atoms/ContentHeader'

import './style.css'

import JobItem from './JobItem'
import { useDispatch, useSelector } from 'react-redux'
import { getLatestJobs } from '../../../redux/LatestJob/action'

const dummyData = [
    {
        name: 'Social Media Assistant',
        type: 'Agency',
        location: 'Paris, France',
        jobType: 'Full-Time',
        categories: ['Marketing', 'Design']
    }
]

export default function LatestJobs() {
    const {jobs} = useSelector((state) => state.latestJob)
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(
            getLatestJobs()
        )
    }, [])


  return (
    <div className='job-wrapper'>
        <ContentHeader word1='Latest' word2='jobs open' />
        <div className='job-content'>
            {jobs.map((item, i) => (
                <JobItem {...item} key={i} />
            ))}
        </div>
    </div>
  )
}
