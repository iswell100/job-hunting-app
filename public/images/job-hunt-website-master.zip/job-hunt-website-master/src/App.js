import './App.css'
import styles from './custom.module.css'

const style = {
  color: 'blue',
  backgroundColor: 'lightblue',
  padding: '10px'
}

function App() {
  return (
    <div className={styles.box2}>
      Hello World
    </div>
  );
}

export default App;
